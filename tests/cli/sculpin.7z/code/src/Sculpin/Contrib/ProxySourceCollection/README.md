Sculpin Proxy Source Collection
===============================

Provides building blocks for building and configuration data providers that are
backed by a collection of `ProxySource` instances.

Visit [sculpin.io](http://sculpin.io) for more information.


License
-------

MIT, see LICENSE.


Community
---------

Want to get involved? Here are a few ways:

* Find us in the **#sculpin** IRC channel on **irc.freenode.org**.
* Join the [Sculpin Users](http://groups.google.com/group/sculpin-users)
  mailing list.
* Mention [@getsculpin](http://twitter.com/getsculpin) on Twitter.
