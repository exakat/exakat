<?php

namespace Sculpin\Tests\Functional\EventListenerTestFixtureBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EventListenerTestFixtureBundle extends Bundle
{
}
